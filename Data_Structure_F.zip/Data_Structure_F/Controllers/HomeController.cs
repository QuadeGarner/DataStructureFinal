using Data_Structure_F.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace Data_Structure_F.Controllers
{
    public class HomeController : Controller
    {
        // basic controller that handle the landing page 
        private AnimalContext context { get; set; }

        public HomeController(AnimalContext ctx)
        {
            context = ctx;
        }

        public IActionResult Index()
        {
            var animal = context.Animals
                .OrderBy(a => a.AnimalName)
                .ToList();
            return View(animal);
        }
    }
}
