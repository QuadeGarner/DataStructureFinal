﻿using Data_Structure_F.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace Data_Structure_Final.Controllers
{
    public class AnimalController : Controller
    {
        // create a context object for the controller to use 
        private AnimalContext context { get; set; }
        public AnimalController(AnimalContext ctx) => context = ctx;
        // IActionResultMethods 
        [HttpGet]
        public IActionResult Add()
        {
            ViewBag.Action = "Add";
            return View("Edit", new Animal());
        }
        [HttpGet]
        public IActionResult Edit(int id)
        {
            ViewBag.Action = "Edit";
            var animal = context.Animals.Find(id);
            return View(animal);
        }
        [HttpGet]
        public IActionResult AddVaccine(int id)
        {
            ViewBag.Action = "Add";
            var animal = context.Animals.Find(id);
            return View(animal);
        }
        [HttpGet]
        public IActionResult View(int id)
        {
            ViewBag.Action = "View";
            var animal = context.Animals.Find(id);
            return View(animal);
        }
        [HttpPost]
        public IActionResult Edit(Animal animal)
        {
            if (ModelState.IsValid)
            {
                if (animal.AnimalId == 0)
                    context.Animals.Add(animal);

                else
                    context.Animals.Update(animal);
                context.SaveChanges();
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ViewBag.Action = (animal.AnimalId == 0) ? "Add" : "Edit";
                return View(animal);
            }
        }
        [HttpPost]
        public IActionResult AddVaccine(Animal animal, int Id, string Name)
        {
            if (ModelState.IsValid)
            {
                if (animal.AnimalId == 0)
                    context.Animals.Add(animal);

                else

                    animal.add(Name, Id);

                context.SaveChanges();
                return RedirectToAction("View", new { id = animal.AnimalId });
            }
            else
            {
                ViewBag.Action = (animal.AnimalId == 0) ? "Add" : "Edit";
                return View(animal);
            }
        }
        [HttpPost]
        public IActionResult AddLineage(Animal animal, Animal animal2)
        {
            ViewBag.Animals = context.Animals.Where(m => m.AnimalId != animal.AnimalId).OrderBy(m => m.AnimalId).ToList();
            if (ModelState.IsValid)
            {
                ViewBag.Action = "Add Linegae to " + animal.AnimalName;
                if (animal.AnimalId == 0)
                    context.Animals.Add(animal);

                else

                    animal.insert(animal2);

                return View(animal);
            }
            else
            {
                ViewBag.Action = (animal.AnimalId == 0) ? "Add" : "Edit";
                return View(animal);
            }
        }
        [HttpGet]
        public IActionResult ViewFamilyLineage(int id)
        {
            ViewBag.Action = "ViewFamilyLineage";
            var animal = context.Animals.Find(id);
            return View(animal);
        }
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var animal = context.Animals.Find(id);
            return View(animal);
        }
        [HttpPost]
        public IActionResult Delete(Animal animal)
        {
            context.Remove(animal);
            context.SaveChanges();
            return RedirectToAction("Index", "Home");
        }

    }
}