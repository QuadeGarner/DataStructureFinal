﻿using Microsoft.EntityFrameworkCore;

namespace Data_Structure_F.Models
{
    public class AnimalContext : DbContext
    {
        // context class, that seeds the database with a entry
        public AnimalContext(DbContextOptions<AnimalContext> options): base(options) { }
        public DbSet<Animal> Animals { get; set; } = null!;
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Animal>().HasData(
                new Animal
                {
                    AnimalId = 1,
                    AnimalName = "Test",
                    AnimalAge = 1,
                    Specices = "cow",
                    Breed = "longhorn",

                }) ;
        }
    }
}
