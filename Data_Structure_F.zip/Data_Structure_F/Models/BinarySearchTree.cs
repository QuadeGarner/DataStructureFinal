﻿namespace Data_Structure_F.Models
{
    public class BinarySearchTree 
    {
        // properties
        public Node root;
        public int size = 0;
        //constructor
        public BinarySearchTree()
        {
            root = null!;
        }
        // method 
        public bool isEmpty()
        {
            if (root == null)
            {
                return true;
            }
            return false;
        }
        public int Size()
        {
            if (size == 0)
            {
                return 0;
            }
            else
            {
                return size;
            }
        }
        public void insert(Animal animal)
        {
            Node newNode = new Node(animal.AnimalId, animal.AnimalName, animal.AnimalAge);
            if (root == null)
            {
                root = newNode;
                return;
            }
            else
            {
                Node cur = root;
                Node par = null!;
                while (true)
                {
                    par = cur;
                    int? add = animal.AnimalAge - cur.Age;
                    if (add < 0)
                    {
                        par.Left = newNode;
                        size++;
                        return;
                    }
                    else
                    {
                        cur = cur.Right;
                        if (cur == null)
                        {
                            par.Right = newNode;
                            size++;
                            return;
                        }
                    }
                }
            }
        }
        public string re = "";
        public string inOrder(Node node)
        {
            if (root == null)
            {
                return re;
            }
            else
            {
                if (node.Left != null)
                    inOrder(node.Left);
                re += (node.Id + " " + node.Name) + "\n";
                if (node.Right != null)
                    inOrder(node.Right);
                return re;
            }
        }
        string p1 = "";
        public string levelOrder()
        {
            int h = hieght(root);
            int i;
            for (i = 1; i <= h; i++)
            {
                p1 = printCurrentLevel(root, i);
            }
            return p1;
        }

        string res = string.Empty;
        public int hieght(Node root)
        {
            if (root == null)
            {
                return 0;
            }
            else
            {
                int lhieght = hieght(root.Left);
                int rhieght = hieght(root.Right);
                if (lhieght > rhieght)
                {
                    return lhieght + 1;
                }
                else
                {
                    return rhieght + 1;
                }
            }
        }
        public string printCurrentLevel(Node root, int level)
        {
            if(root == null)
            {
                return "";
            }
            if(level == 1)
            {
                res += (root.Id + " " + root.Name);
            }
            else if (level > 1)
            {
                printCurrentLevel(root.Left, level - 1);
                printCurrentLevel(root.Right, level - 1);
            }
            return res;
        }
        public string compareTo(Animal animal)
        {
            string name = animal.Name;
            string res = "The " + name + "was not found";
            if (root == null)
            {
                res = "Tree is Empty";
                return res;
            }
            else
            {
                Node node = root;
                while ( node != null)
                {
                    if (name.CompareTo(node.Name) < 0)
                    {
                        node = node.Left;
                    }
                    else if (name.CompareTo(node.Right) > 0)
                    {
                        node = node.Right;
                    }
                    else
                    {
                        res += "Yes";
                        break;
                    }
                }
                return res;
            }
            
        }
        public override string ToString()
        {
            return root.Name + " " + root.Age;
        }
    }
}
