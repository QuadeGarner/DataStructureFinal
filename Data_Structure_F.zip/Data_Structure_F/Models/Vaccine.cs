﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Data_Structure_F.Models
{
    public class Vaccine
    {
        // getter and setters
        public int VaccineId { get; set; } 
        public string VaccineName { get; set; } = string.Empty;
        // para constructor
        public Vaccine(int vaccineId, string vaccineName)
        {
            VaccineId = vaccineId;
            VaccineName = vaccineName;
        }
        // overrided ToString method
        public override string ToString()
        {
           
            return VaccineId+ " " + VaccineName;
        }

    }
}
