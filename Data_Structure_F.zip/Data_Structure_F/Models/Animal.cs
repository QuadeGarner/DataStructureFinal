﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Data_Structure_F.Models
{
    public class Animal
    {
        // properties
        private static LinkedList<Vaccine> _Vaccines = new LinkedList<Vaccine>();

        private static BinarySearchTree _SearchTree = new BinarySearchTree();
        private static LinkedListNode<Vaccine> head = new LinkedListNode<Vaccine>(new Vaccine(0, "first"));
        // getters and set 
        [Key]
        public int AnimalId { get; set; }
        public string AnimalName { get; set; } = string.Empty;
        [Required]
        [Range(0, 35, ErrorMessage = " Please Enter a Age!")]
        public int? AnimalAge { get; set; }
        public string Specices { get; set; } = string.Empty;
        public string Breed { get; set; } = string.Empty;
        [NotMapped]
        public string Name { get; set; } = string.Empty;
        [NotMapped]
        public int Id { get; set; }
        [NotMapped]
        public BinarySearchTree SearchTree { get => _SearchTree; set => _SearchTree = value; }
        [NotMapped]
        public LinkedList<Vaccine> Vaccines { get => _Vaccines; set => _Vaccines = value; }
        // methods 
        public override string ToString()
        {
            string vaccineString = string.Empty;
            for (int i = 0; i < Vaccines.Count(); i++)
            {
                vaccineString += Vaccines.ElementAt(i).ToString() + "\n";
            }
            return vaccineString;
        }

        public void add(string Name, int Id)
        {
            Vaccine v = new Vaccine(Id, Name);
            if (Vaccines.Count == 0)
            {
                Vaccines.AddFirst(head);
            }
            Vaccines.AddLast(v);
            Vaccines = SelectionSort(Vaccines, head);

        }
        // inserts the animal in to the BiranerySearchTree
        public void insert(Animal animal2)
        {
            SearchTree.insert(animal2);
        }
        public LinkedList<Vaccine> SelectionSort(LinkedList<Vaccine> Vaccines, LinkedListNode<Vaccine> head)
        {

            LinkedListNode<Vaccine> temp = head;
            while (temp.Next != null)
            {
                LinkedListNode<Vaccine> r = temp;
                LinkedListNode<Vaccine> min = temp;
                while (r.Next != null)
                {
                    if (min.Value.VaccineId < r.Next.Value.VaccineId)

                        min = r;
                    r = r.Next;

                }
                int x = temp.Value.VaccineId;
                temp.Value.VaccineId = min.Value.VaccineId;
                min.Value.VaccineId = x;
                temp = temp.Next;
            }
            return Vaccines;
        }
            


        
}
}
