﻿namespace Data_Structure_F.Models
{
    // Basic node class, used by the binary search tree
    public class Node
    {
        public int Id = 0;
        public string Name = string.Empty;
        public int? Age = 0;
        public Node Right;
        public Node Left;
        public Node (int Id, string Name , int? age)
        {
            this.Id = Id;
            this.Name = Name;
            this.Left = null!;
            this.Right = null!;
            this.Age = age;
        }

    }
}
